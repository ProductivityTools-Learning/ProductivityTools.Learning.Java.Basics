package top.productivitytools.learning.GraphQL.pwdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
