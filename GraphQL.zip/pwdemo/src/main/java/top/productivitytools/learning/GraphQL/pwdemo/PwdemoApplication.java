package top.productivitytools.learning.GraphQL.pwdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwdemoApplication.class, args);
	}

}
