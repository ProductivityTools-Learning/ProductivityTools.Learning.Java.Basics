package top.productivitytools.learning.GraphQl.pwdemoapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwdemoapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwdemoapplicationApplication.class, args);
	}

}
