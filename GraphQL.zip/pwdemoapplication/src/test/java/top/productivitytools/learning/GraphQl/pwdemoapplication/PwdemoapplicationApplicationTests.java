package top.productivitytools.learning.GraphQl.pwdemoapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwdemoapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
